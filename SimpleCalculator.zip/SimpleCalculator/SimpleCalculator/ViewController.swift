//
//  ViewController.swift
//  SimpleCalculator
//
//  Created by Sahiri,Naina on 9/1/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultLabel: UILabel!
    var operand1:Double = -1.1
    var operand2:Double = -1.1
    var calcOperator:Character = " "
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func button8Clicked(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"8"
        if(operand1 == -1.1){
            operand1 = 8
        }else{
            operand2 = 8
        }
    }
    
    @IBAction func button9Clicked(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"9"
        if(operand2 == -1.1){
            operand2 = 9
        }else{
            operand1 = 9
        }
    }
    @IBAction func buttonPlusClicked(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"+"
        //As the user clicks plus symbol, we need to assign the calcOperator to +
        if(calcOperator == " "){
            calcOperator = "+"
        }
        
    }
    @IBAction func buttonEqualsClicked(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"="
        if (calcOperator == "+"){
            resultLabel.text = "\(operand1+operand2)"
        }

    }
    
    @IBAction func resetButton(_ sender: UIButton) {
        resultLabel.text = " "
        operand1 = -1.1
        operand2 = -1.1
        calcOperator = " "
    }
}
    

