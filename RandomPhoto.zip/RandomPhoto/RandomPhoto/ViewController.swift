//
//  ViewController.swift
//  RandomPhoto
//
//  Created by Meena Ankam on 5/29/23.
//

import UIKit

class ViewController: UIViewController {
    
    private let imageView : UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleToFill
        imageView.backgroundColor = .white
        return imageView
    }()
    private let button : UIButton = {
        let button = UIButton()
        button.backgroundColor = .white
        button.setTitle("Random Photo", for: .normal)
        button.setTitleColor(.black, for: .normal)
        return button
    }()
    
    let colors: [UIColor] = [
        .systemPink,
        .systemBlue,
        .systemGreen,
        .systemYellow,
        .systemPurple,
        .systemOrange
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .systemPink
        view.addSubview(imageView)
        imageView.frame = CGRect(x:0, y:0, width: 300, height: 300)
        imageView.center = view.center
        view.addSubview(button)
        getRandomPhoto()
        button.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
    }
    
    @objc func didTapButton(){
        getRandomPhoto()
        view.backgroundColor = colors.randomElement()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        button.frame = CGRect(x: 20,
                              y: view.frame.size.height-150-view.safeAreaInsets.bottom,
                              width: view.frame.size.width-60,
                              height: 55
        )
    }
    func getRandomPhoto(){
        let urlString = "https://api.unsplash.com/photos/random"
        let accessKey = "xqJjHqbmOa-gzyufVBzMuRepcICb5mfNy2pgiBy0Odc"
        let apiUrlWithAccessKey = "\(urlString)?client_id=\(accessKey)"
        guard let url = URL(string: apiUrlWithAccessKey) else {
                return
            }
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if let error = error {
                    // Handle error
                    print("Error: \(error.localizedDescription)")
                    return
                }

                if let data = data {
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                            if let urls = json["urls"] as? [String: String], let photoURLString = urls["regular"], let photoURL = URL(string: photoURLString) {
                                URLSession.shared.dataTask(with: photoURL) { (imageData, _, _) in
                                    if let imageData = imageData {
                                        DispatchQueue.main.async {
                                            self.imageView.image = UIImage(data: imageData)
                                        }
                                    }
                                }.resume()
                            }
                        }
                    } catch {
                        // Handle JSON parsing error
                        print("Error parsing JSON: \(error.localizedDescription)")
                    }
                }
            }

        task.resume();
        }
}

