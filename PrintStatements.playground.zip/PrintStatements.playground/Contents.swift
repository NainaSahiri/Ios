import UIKit

var greeting = "Hello, playground"

print("Hello World")
print(greeting)

print("hi", 10, 10.5)

print("Hello World!" + greeting)

print("Hello World \(greeting)")

var age = 12
print("My age \(age)") //String interpolation

//print("My age is "+ age)//concatenation of different datatypes is not allowed

print("you are \(age) years old and in another \(age) years, you will be \(age * 2)")

print("""
Hello
World!
from the US
""")

print("Hello All,\rWelcome to Swift Programming")

let welcomeMessage: String = "Hello!"
print(welcomeMessage , "All")
//welcomeMessage = "Good bye" cannot change the constants

var name:String = "John"
print(name, 2, "Smith")
name = "Bob"
print(name)

print("Welcome to Swift Programming")
print("Fall 2021")
print("*******************************")
print("Welcome to Swift Programming" , terminator: "$")
print("Fall 2022")

print("The list of numbers are")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator:  "@")
