//
//  ViewController.swift
//  Sahiri_Calculator
//
//  Created by Sahiri,Naina on 9/27/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var resultLabel: UILabel!
        var opr1 = ""
        var opr2 = ""
        var result = " "
    
    @IBAction func ACButton(_ sender: UIButton) {
        resultLabel.text?.removeAll()
        result = " "
        opr1 = ""
        opr2 = ""
    }
    
    @IBAction func CButton(_ sender: UIButton) {
        resultLabel.text?.removeAll()
    }
    
    @IBAction func ChangeSignButton(_ sender: UIButton) {
        resultLabel.text = "-" + resultLabel.text!
    }
    
    @IBAction func DivisionButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"÷"
               
               if(result == " "){
                   result = "/"
               }
    }
    @IBAction func SevenButton(_ sender: UIButton) {
        if(result == " "){
            opr1 = opr1 + "7"
               }
               else{
                   opr2 = opr2 + "7"
               }
    }
    
    @IBAction func EightButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"8"
               if(result == " "){
                   opr1 = opr1 + "8"
               }
               else{
                   opr2 = opr2 + "8"
               }
    }
    
    @IBAction func NineButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"9"
              if(result == " "){
                  opr1 = opr1 + "9"
              }
              else{
                  opr2 = opr2 + "9"
              }
    }
    
    @IBAction func MultiplyButtonm(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"x"
            
            if(result == " "){
                result = "*"
            }
    }
    
    @IBAction func FourButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"4"
               if(result == " "){
                   opr1 = opr1 + "4"
               }
               else{
                   opr2 = opr2 + "4"
               }
    }
    
    @IBAction func FiveButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"5"
                if(result == " "){
                    opr1 = opr1 + "5"
                }
                else{
                    opr2 = opr2 + "5"
                }
    }
    
    @IBAction func SixButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"6"
                if(result == " "){
                    opr1 = opr1 + "6"
                }
                else{
                    opr2 = opr2 + "6"
                }
    }
    
    @IBAction func SubButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"-"
                
                if(result == " "){
                    result = "-"
                }
    }
    
    @IBAction func OneButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"1"
                if(result == " "){
                    opr1 = opr1 + "1"
                }
                else{
                    opr2 = opr2 + "1"
                }
                
    }
    
    @IBAction func TwoButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"2"
                if(result == " "){
                    opr1 = opr1 + "2"
                }
                else{
                    opr2 = opr2 + "2"
                }
                
    }
    
    @IBAction func ThreeButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"3"
                if(result == " "){
                    opr1 = opr1 + "3"
                }
                else{
                    opr2 = opr2 + "3"
                }
    }
    
    @IBAction func AddButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text! + "+"
               
               if(result == " "){
                   result = "+"
               }
    }
    
    @IBAction func ZeroButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"0"
                if(result == " "){
                    opr1 = opr1 + "0"
                }
                else{
                    opr2 = opr2 + "0"
                }
    }
    
    @IBAction func DotButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"."
                
                if(result == " "){
                    opr1 = opr1 + "."
                }
                else{
                    opr2 = opr2 + "."
                }
    }
    
    @IBAction func PercentileButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text!+"%"
                
                if(result == " "){
                    result = "%"
                }
    }
    
    @IBAction func EButton(_ sender: UIButton) {
        
        
        switch result {
        case "-":
            resultLabel.text = "\(Int((Double(opr1)!-Double(opr2)!)))"
        case "+":
            resultLabel.text = "\(Int((Double(opr1)!+Double(opr2)!)))"
        case "*":
            resultLabel.text = "\(Int((Double(opr1)!*Double(opr2)!)))"
        case "/":
            let val = "\(Double(opr1)!/Double(opr2)!)"
                               if(val == "inf"){
                                   resultLabel.text = "Error"
                               }else{
                                   resultLabel.text = "\(round(Double(val)! * 100000)/100000)"
                               }
        case "%":
            let rem:Double = Double(opr1)!.truncatingRemainder(dividingBy:Double(opr2)!)
                               resultLabel.text = "\(round(rem * 100)/100 )"
        default:
            resultLabel.text = "Error"
        }
//        print(opr1)
//               print(opr2)
//
//               if(result == "+"){
//                   resultLabel.text = "\(Int((Double(opr1)!+Double(opr2)!)))"
//               }
//
//               else if(result == "-"){
//                   resultLabel.text = "\(Int((Double(opr1)!-Double(opr2)!)))"
//               }
//
//               else if(result == "/"){
//                   let val = "\(Double(opr1)!/Double(opr2)!)"
//                   if(val == "inf"){
//                       resultLabel.text = "Error"
//                   }else{
//                       resultLabel.text = "\(round(Double(val)! * 100000)/100000)"
//                   }
//
//               }
//
//               else if(result == "*"){
//                   resultLabel.text = "\(Int((Double(opr1)!*Double(opr2)!)))"
//               }
//
//               else{
//
//               }
//    }
}
}
