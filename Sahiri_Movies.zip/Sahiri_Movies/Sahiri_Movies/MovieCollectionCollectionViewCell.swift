//
//  MovieCollectionCollectionViewCell.swift
//  Sahiri_Movies
//
//  Created by Sahiri,Naina on 11/30/22.
//

import UIKit

class MovieCollectionCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
        
//        func assignMovie(with movie: Movie){
     //       imageViewOutlet.image = movie.image
       // }
    
}
