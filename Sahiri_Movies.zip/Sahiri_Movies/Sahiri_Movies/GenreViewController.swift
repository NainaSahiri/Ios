//
//  ViewController.swift
//  Sahiri_Movies
//
//  Created by Sahiri,Naina on 11/30/22.
//

import UIKit

class GenreViewController: UIViewController{
    
    @IBOutlet weak var genreTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

   

}


