//
//  ViewController.swift
//  FirstFourCharacters
//
//  Created by Sahiri,Naina on 9/8/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameOutlet: UILabel!
    
  
    @IBOutlet weak var displayOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitButtonClicked(_ sender: UIButton) {
        var name = nameOutlet.text!
       //var output = text[text.index(text.startIndex, offsetBy: 4)]
        
        //print(text.startIndex)
        //displayOutlet.text = String(output)
        
        if(name.count >= 4){
            //var fourChar = name[name.startIndex .. < name.index(name.startIndex,offsetBy: 4)]
            var fourChar = name.prefix(4)
            displayOutlet.text = "\(fourChar)"
        }
    }
}
 
