//
//  ViewController.swift
//  Sahiri_WordGuess
//
//  Created by Sahiri,Naina on 10/27/22.
//

import UIKit

class ViewController: UIViewController {
   
    @IBOutlet weak var wordsGuessedLabel: UILabel!
        
    @IBOutlet weak var wordsRemainingLabel: UILabel!
        
    @IBOutlet weak var totalWordsLabel: UILabel!
        
    @IBOutlet weak var userGuessLabel: UILabel!
        
    @IBOutlet weak var guessLetterField: UITextField!
        
    @IBOutlet weak var hintLabel: UILabel!
        
    @IBOutlet weak var statusLabel: UILabel!
        
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var guessLetterButton: UIButton!
        
    @IBOutlet weak var playAgain: UIButton!
        
    
    var wordarray = [["CHARMINAR","mosque and monument","Charminar"],
        ["DOG","most loved animal","dog"],
        ["FLOWER","bloom and blossom","flower"],
        ["AUDI","The one with four rings car","audi"],
        ["VIRATKOHLI","former Indian cricketer","virat"]]
    
    var letterGuessed = ""
    var arrIndex = 0
    var exp = ""
    
    //var images = ["Charminar","dog","flower","audi","virat","giveup"]
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        exp = wordarray[arrIndex][0]
        userGuessLabel.text = ""
        updateUnderscores();
        guessLetterButton.isEnabled = false;
                
                
        hintLabel.text = hintLabel.text! + wordarray[arrIndex][1];
        playAgain.isHidden = true;
                
                
        statusLabel.text = "This is a status label";
        totalWordsLabel.text = totalWordsLabel.text!.components(separatedBy: ":")[0] + ": \(wordarray.count)";
        wordsGuessedLabel.text = wordsGuessedLabel.text!.components(separatedBy: ":")[0] + ": 0";
        wordsRemainingLabel.text = wordsRemainingLabel.text!.components(separatedBy: ":")[0] + ": \(wordarray.count)"
        displayImage.image = nil
    }
    
    func updateUnderscores(){
        for _ in exp{
            userGuessLabel.text! += "- "
        }
    }
        
        
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
            
        let alphabet = guessLetterField.text!
            
            letterGuessed = letterGuessed + alphabet
            var revealtedexp = ""
            print(exp)
            for l in exp{
                if letterGuessed.contains(l){
                    revealtedexp += "\(l)"
                }
                else{
                    revealtedexp += "_ "
                }
            }
            
            userGuessLabel.text = revealtedexp
            guessLetterField.text = ""
            
            
            if userGuessLabel.text!.contains("_") == false{
                playAgain.isHidden = false;
                guessLetterButton.isEnabled = false;
                displayImage.image = UIImage(named: wordarray[arrIndex][2])
                let number = wordsRemainingLabel.text!.components(separatedBy: ":")
                wordsRemainingLabel.text = number[0] + ": \(wordarray.count - arrIndex - 1)"
                wordsGuessedLabel.text = wordsGuessedLabel.text!.components(separatedBy: ":")[0] + ": \(arrIndex+1)"
            }
            guessLetterButton.isEnabled = false
        }
        
        
        @IBAction func playAgainButtonPressed(_ sender: UIButton) {
            
            playAgain.isHidden = true
            statusLabel.numberOfLines = 2
            letterGuessed = ""
            arrIndex = arrIndex + 1
            
            if arrIndex == wordarray.count{
                displayImage.image = UIImage(named: "giveup")
                statusLabel.text = "Congratulations, You are done, \nPlease start over again"
                userGuessLabel.text = ""
                hintLabel.text = ""
                playAgain.isHidden = false
                arrIndex = -1;
                
            }
            else{
                if(statusLabel.text! == "Congratulations, You are done, \nPlease start over again"){
                    viewDidLoad();
                }
                exp = wordarray[arrIndex][0]
                hintLabel.text = "Hint: "
                hintLabel.text! += wordarray[arrIndex][1]
                userGuessLabel.text = ""
                updateUnderscores()
            }
        }
        
    @IBAction func guessLetterFieldChanged(_ sender: UITextField) {
            
            var alphabetPressed = guessLetterField.text!;
            alphabetPressed = String(alphabetPressed.last ?? " ").trimmingCharacters(in: .whitespaces)
            guessLetterField.text = alphabetPressed
            if alphabetPressed.isEmpty{
                guessLetterButton.isEnabled = false
            }
            else{
                guessLetterButton.isEnabled = true
            }
        }

}

