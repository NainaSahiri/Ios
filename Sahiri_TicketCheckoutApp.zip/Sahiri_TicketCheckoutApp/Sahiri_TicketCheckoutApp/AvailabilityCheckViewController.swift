//
//  ViewController.swift
//  Sahiri_TicketCheckoutApp
//
//  Created by Sahiri,Naina on 11/3/22.
//

import UIKit

class AvailabilityCheckViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var bookingIdOutlet: UITextField!
    
    @IBOutlet weak var imageOutlet: UIImageView!
    
    @IBOutlet weak var displayStatusOutlet: UILabel!
    
    //creating a global variable for holding a student
    //var ticketFound = Ticket()
    
    //var guestUser:Bool = false
    //to check whether user is Ticket/guest
    //Initially isTicket is false that means user is a guest
    var isTicket = false
    
    
    
    //Array of type Ticket, we imported it from the 'Ticket' file
    var TicketsArray = Ticket()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        nameOutlet.text = ""
        bookingIdOutlet.text = ""
        imageOutlet.image = UIImage(named:default.png)
        if(statusdisplay){
            
        }else{
            status not found
        }
        
    }

   @IBAction func AvailabilityCheck(_ sender: UIButton) {
       if isTicket {
                //if the user is guest we will hide all the outlets and display 'Guest User'
                //emailOutlet.isHidden = true
           nameOutlet.isHidden = true
           //nameOutlet.text = "Name: Guest User"
           bookingIdOutlet.text = "Booking Id Not found"
           imageOutlet.isHidden = true
           displayStatusOutlet.isHidden = true
                
            }else{
                
                //If the student is found, then we assign the values of the studentObj to the outelts
                bookingIdOutlet.text = TicketsArray.bookingID
               // imageOutlet.image = UIImage(named:airlineImage)
                nameOutlet.text = TicketsArray.airlineName
                displayStatusOutlet.text = TicketsArray.bookingID + "is found"
            }
            
        }
     //let enteredID = bookingIdOutlet.text!
        
        //Loop the array to find the student
       // for Ticket in TicketsArray {
         //  if enteredID == Ticket.bookingID{
                //student found and store the student in a global variable.
           //     ticketFound = Ticket
                //boolean flag as true,since we found a student.
             // isTicket = true
                
           //}
       // }
   // }
  // }
   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       let transition = segue.identifier
       if transition == "checkoutSegue"{
            //Create a destination of type studentInfoViewController
            let destination = segue.destination as! CheckoutTicketViewController
            
            //if student is exists in the array, we will assign the studentObj in the destination with "studentFound"
            //if isStudent {
               // destination.ticketFound = ticketFound
            //}else{
                //if the given sid is not in the array, then the student is a guest!!
                //we set the boolean in the destination as true!!
                //destination.guestUser = true
            //}
            
            
    //}
   }
    
}

