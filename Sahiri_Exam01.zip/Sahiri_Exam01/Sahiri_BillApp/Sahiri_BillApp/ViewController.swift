//
//  ViewController.swift
//  Sahiri_BillApp
//
//  Created by Sahiri,Naina on 10/4/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayProductName: UILabel!
    
    @IBOutlet weak var displayUnits: UILabel!
    
    
    var amount = ""
    //var discount = ""
    //var priceAfterDiscount = ""
    @IBAction func calDiscount(_ sender: UIButton) {
        
        var enteredProduct = displayProductName.text!
        var enteredUnits = Int(displayUnits.text!)
       // var actualAmount = enteredAmount*enteredUnits
       // var discountPrice = actualAmount-(actualAmount!*enteredUnits!/100)
        
        //priceAfterDiscount = enteredAmount!-(enteredAmount!*enteredUnits!/100)
        //if(displayProductName.text = Perfume){
          //  discount = 10
       // }else if(displayProductName.text = T-Shirt){
        //    discount = 4
       // }else{
       //     discount = 0
      //  }
        
    //    var priceAfterDiscount = amount!-(displayUnits!*discount!/100)
        
      //  priceAfterDiscount.text = "Price After discount is : $ \(priceAfterDiscount)"
    }
    
    @IBOutlet weak var priceBeforeDiscount: UILabel!
    
    @IBOutlet weak var priceAfterDiscount: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

}

