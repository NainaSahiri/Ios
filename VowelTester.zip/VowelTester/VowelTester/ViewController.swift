//
//  ViewController.swift
//  VowelTester
//
//  Created by Sahiri,Naina on 8/30/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var enteredText: UITextField!
    
   
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitButtonClicked(_ sender: UIButton) {
        //Read the text from text field and assign to a local variable
        var text = enteredText.text!
        
        //Check the text has vowel or not
        if(text.contains("a")||text.contains("e") || text.contains("i")||text.contains("o")||text.contains("u")){
            //vowel is in the text
            displayLabel.text = "The text has vowel."
        }
        else{
            displayLabel.text = "No vowels found"
        }
    }
    
}

