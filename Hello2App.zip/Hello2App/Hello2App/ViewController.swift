//
//  ViewController.swift
//  Hello2App
//
//  Created by Sahiri,Naina on 8/30/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var displayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitButtonClicked(_ sender: UIButton) {
        //read the text from text field and asign it to a local variable
        var name = nameOutlet.text!
        //exclamation is to unwrap the text
        //assign the data(entered name) to the display label.
        displayLabel.text = "Hello, \(name)!";
        
    }
    
}

