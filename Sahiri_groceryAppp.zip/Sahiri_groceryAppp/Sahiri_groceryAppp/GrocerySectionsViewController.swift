//
//  ViewController.swift
//  Sahiri_groceryAppp
//
//  Created by Sahiri,Naina on 11/17/22.
//

import UIKit

class GrocerySectionsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return marketshoparray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var view = grocerySectionsTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        view.textLabel?.text = marketshoparray[indexPath.row].section
        return view
    }
    
    var marketshop = Grocery()
    
    var marketshoparray = shops

    @IBOutlet weak var grocerySectionsTableView: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.title = "Grocery Sections"
        // Do any additional setup after loading the view.
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemSegue"{
            let destination = segue.destination as! GroceryItemsViewController
            destination.marketItems = marketshoparray[(grocerySectionsTableView.indexPathForSelectedRow?.row)!]

        }
    }


}

