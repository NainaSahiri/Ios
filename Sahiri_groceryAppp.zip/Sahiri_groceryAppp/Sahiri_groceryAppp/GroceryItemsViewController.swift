//
//  GroceryItemsViewController.swift
//  Sahiri_groceryAppp
//
//  Created by Sahiri,Naina on 11/17/22.
//

import UIKit

class GroceryItemsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return marketshoparray.count
    }
    
    var marketItems : Grocery?
 

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var view = groceryItemsTableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath)
        view.textLabel?.text = marketItems!.items_Array[indexPath.row].itemName
        return view
        
    }
    var marketshop = GroceryItem()

    var marketshoparray = shops
    

    @IBOutlet weak var groceryItemsTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = marketItems?.section
        groceryItemsTableView.delegate = self
        groceryItemsTableView.dataSource = self

        // Do any additional setup after loading the view.
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemInfoSegue"{
            let destination = segue.destination as! ItemInfoViewController
            destination.list = marketItems!.items_Array[(groceryItemsTableView.indexPathForSelectedRow?.row)!]
        }
   

}
}

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


