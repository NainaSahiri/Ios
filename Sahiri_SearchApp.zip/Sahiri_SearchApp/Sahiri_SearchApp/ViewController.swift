//
//  ViewController.swift
//  Sahiri_SearchApp
//
//  Created by Sahiri,Naina on 10/13/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
        
        @IBOutlet weak var resultImage: UIImageView!
        
        @IBOutlet weak var topicInfoText: UITextView!
        
       
        
        @IBOutlet weak var searchButtonAction: UIButton!
        
        @IBOutlet weak var resetButton: UIButton!
        
        @IBOutlet weak var showPrevImagesBtn: UIButton!
        
        @IBOutlet weak var showNextImagesBtn: UIButton!
    
    var arr = [["flag1","flag2","flag3","flag4","flag5"],["usstate1","usstate2","usstate3","usstate4","usstate5"],["vehicle1","vehicle2","vehicle3","vehicle4","vehicle5"]]
    
    var flag = ["flag","country","symbol","banner","flags","usa","india","canada","australia","bhutan"]
    var usstates = ["state","iowa","arizona","new york","utah","St louis","states"]
    var vehicle = ["bike","cycle","car","truck","scooty","vehicle","travel","vehicles"]
    
    var topic = 0
    var imag1:Int!
    var imag2:Int!
    var imag3:Int!
    var name1:Int!
    var name2:Int!
    var name3:Int!
    var text1:Int!
    var text2:Int!
    var text3:Int!
        

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        showPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
        searchButtonAction.isEnabled = false
        resetButton.isHidden = true
        resultImage.image = UIImage(named: arr[3][0])
        topicInfoText.text = nil
           }
    @IBAction func searchTextField(_ sender: UITextField) {
            searchButtonAction.isEnabled = true
            if(sender.text == ""){
                searchButtonAction.isEnabled = false
                
            }
            else{
                showPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = false
                searchButtonAction.isEnabled = true
                resetButton.isHidden = false
            }
    }
    var flags = [["usa","india","canada","australia","bhutan"],["The U.S. is a country of 50 states covering a vast swath of North America, with Alaska in the northwest and Hawaii extending the nation’s presence into the Pacific Ocean. Major Atlantic Coast cities are New York, a global finance and culture center, and capital Washington, DC. Midwestern metropolis Chicago is known for influential architecture and on the west coast, Los Angeles' Hollywood is famed for filmmaking."],["India, officially the Republic of India, is a country in South Asia. It is the seventh-largest country by area, the second-most populous country, and the most populous democracy in the world."],["Canada is a country in North America. Its ten provinces and three territories extend from the Atlantic Ocean to the Pacific Ocean and northward into the Arctic Ocean, covering over 9.98 million square kilometres, making it the world's second-largest country by total area."],["Australia, officially the Commonwealth of Australia, is a sovereign country comprising the mainland of the Australian continent, the island of Tasmania, and numerous smaller islands. With an area of 7,617,930 square kilometres, Australia is the largest country by area in Oceania and the world's sixth-largest country."],["Bhutan, a Buddhist kingdom on the Himalayas’ eastern edge, is known for its monasteries, fortresses (or dzongs) and dramatic landscapes that range from subtropical plains to steep mountains and valleys. In the High Himalayas, peaks such as 7,326m Jomolhari are popular trekking destinations. Paro Taktsang monastery (also known as Tiger’s Nest) clings to cliffs above the forested Paro Valley."]]
    
    var usstatess = [["iowa","arizona","new york","utah","St louis"],["Iowa, a Midwestern U.S. state, sits between the Missouri and Mississippi rivers. It’s known for its landscape of rolling plains and cornfields. Landmarks in the capital, Des Moines, include the gold-domed, 19th-century State Capitol Building, Pappajohn Sculpture Park and the Des Moines Art Center, noted for its contemporary collections. The city of Cedar Rapids' Museum of Art has paintings by native Iowan Grant Wood."],["Arizona, a southwestern U.S. state, is best known for the Grand Canyon, the mile-deep chasm carved by the Colorado River. Flagstaff, a ponderosa pine–covered mountain town, is a major gateway to the Grand Canyon. Other natural sites include Saguaro National Park, protecting cactus-filled Sonoran Desert landscape. Tucson is University of Arizona territory and home to the Arizona-Sonora Desert Museum."],["New York City comprises 5 boroughs sitting where the Hudson River meets the Atlantic Ocean. At its core is Manhattan, a densely populated borough that’s among the world’s major commercial, financial and cultural centers. Its iconic sites include skyscrapers such as the Empire State Building and sprawling Central Park. Broadway theater is staged in neon-lit Times Square."],["Utah is a state in the Mountain West subregion of the Western United States. Utah is a landlocked U.S. state bordered to its east by Colorado, to its northeast by Wyoming, to its north by Idaho, to its south by Arizona, and to its west by Nevada. Utah also touches a corner of New Mexico in the southeast."],["St. Louis is a major city in Missouri along the Mississippi River. Its iconic, 630-ft. Gateway Arch, built in the 1960s, honors the early 19th-century explorations of Lewis and Clark and America's westward expansion in general. Replica paddlewheelers ply the river, offering views of the arch. The Soulard district is home to barbecue restaurants and clubs playing blues music. "]]
    
    var vehicles = [["bike","cycle","car","truck","scooty"],["A motorcycle, often called a motorbike, bike, cycle, or trike, is a two- or three-wheeled motor vehicle. Motorcycle design varies greatly to suit a range of different purposes: long-distance travel, commuting, cruising, sport, and off-road riding."],["A bicycle, also called a pedal cycle, bike or cycle, is a human-powered or motor-powered assisted, pedal-driven, single-track vehicle, having two wheels attached to a frame, one behind the other. A bicycle rider is called a cyclist, or bicyclist. Bicycles were introduced in the 19th century in Europe."],["A car is a wheeled motor vehicle that is used for transportation. Most definitions of cars say that they run primarily on roads, seat one to eight people, have four wheels, and mainly transport people instead of goods."],["A truck or lorry is a motor vehicle designed to transport cargo, carry specialized payloads, or perform other utilitarian work. Trucks vary greatly in size, power, and configuration, but the vast majority feature body-on-frame construction, with a cabin that is independent of the payload portion of the vehicle."],["a light two-wheeled open motor vehicle on which the driver sits over an enclosed engine with legs together and feet resting on a floorboard."]]
    
    @IBAction func searchButtonActionAction(_ sender: UIButton) {
            imag1 = 0
            imag2 = 0
            imag3 = 0
            name1 = 0
            name2 = 0
            name3 = 0
            text1 = 0
            text2 = 0
            text3 = 0
            showPrevImagesBtn.isHidden = false
            showNextImagesBtn.isHidden = false
            showPrevImagesBtn.isEnabled = false
            showNextImagesBtn.isEnabled = false
            resetButton.isEnabled = true
            if(flag.contains(searchTextField.text!)){
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = false
                resultImage.image = UIImage(named: arr[0][imag1])
                
                topic = 1
                topicInfoText.text = flags[1][text1]
            }
            else if(usstates.contains(searchTextField.text!)){
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = false
                resultImage.image = UIImage(named: arr[1][imag2])
              
                topic = 2
                topicInfoText.text = usstatess[1][text2]
            }
            else if(vehicle.contains(searchTextField.text!)){
                showNextImagesBtn.isEnabled = true
                showPrevImagesBtn.isEnabled = false
                resultImage.image = UIImage(named: arr[2][imag3])
                 topic = 3
                topicInfoText.text = vehicles[1][text3]
            }
            else{
                resultImage.image = UIImage(named: arr[3][1])
    //            resultImage.image = nil
                topicInfoText.text = nil
                             showPrevImagesBtn.isHidden = true
                showNextImagesBtn.isHidden = true
                resetButton.isEnabled = true
            }
            
            
        }
        

}

