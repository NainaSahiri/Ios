//
//  conformVC.swift
//  Restaurant_FinalProject
//
//  Created by Kalluri,Shanmukha Sriharsha on 12/6/22.
//

import UIKit

class conformVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        conformationLBL.text = message
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var conformationLBL: UILabel!
    var message = ""

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
