//
//  LoginVC.swift
//  Restaurant_FinalProject
//
//  Created by Kalluri,Shanmukha Sriharsha on 12/6/22.
//

import UIKit

class LoginVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        passwordTF.isEnabled = false
        loginBTN.isEnabled = false

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var userNameTF: UITextField!
    
    @IBOutlet weak var passwordTF: UITextField!
    
    
    @IBOutlet weak var loginBTN: UIButton!
    
    
    @IBAction func passwordbtnEnable(_ sender: Any) {
        if userNameTF.text == "admin"{
            passwordTF.isEnabled = true
        }
    }
    
    @IBAction func loginBtnEnable(_ sender: Any) {
        
        if passwordTF.text == "admin"{
            loginBTN.isEnabled = true
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
