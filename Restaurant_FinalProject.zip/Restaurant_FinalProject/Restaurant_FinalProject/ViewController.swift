//
//  ViewController.swift
//  Restaurant_FinalProject
//
//  Created by Kalluri,Shanmukha Sriharsha on 12/6/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

