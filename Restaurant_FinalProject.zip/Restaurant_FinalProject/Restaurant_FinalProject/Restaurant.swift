//
//  Restaurant.swift
//  Restaurant_FinalProject
//
//  Created by Kalluri,Shanmukha Sriharsha on 12/6/22.
//

import Foundation

struct Restaurant {
var section = ""
var items_Array:[MenuItem] = []
}

struct MenuItem{
    var itemName = ""
    var itemImage = ""
    var itemPrice = ""
}

let item1 = Restaurant(section:"Appetizers",items_Array:[MenuItem(itemName:"Chicken 65",itemImage:"Chicken65",itemPrice:"13"), MenuItem(itemName: "ApolloFish", itemImage: "ApolloFish", itemPrice: "8"), MenuItem(itemName: "VegManchuria", itemImage: "VegManchuria", itemPrice: "10"), MenuItem(itemName: "Chilli Paneer", itemImage: "ChilliPaneer", itemPrice: "23")] )

let item2 = Restaurant(section:"MainCourse",items_Array:[MenuItem(itemName:"Chicken Biryani",itemImage:"ChickenBiryani",itemPrice:"15"), MenuItem(itemName: "kadai Paneer", itemImage: "KadaiPaneer", itemPrice: "8"), MenuItem(itemName: "Prawns Fry", itemImage: "PrawnsFry", itemPrice: "12"), MenuItem(itemName: "DalMakhni", itemImage: "DalMakhni", itemPrice: "14")] )

let item3 = Restaurant(section:"Drinks",items_Array:[MenuItem(itemName:"Coke",itemImage:"Coke",itemPrice:"5"), MenuItem(itemName: "Mocktail", itemImage: "Mocktail", itemPrice: "7"), MenuItem(itemName: "Cocktail", itemImage: "Cocktail", itemPrice: "10"), MenuItem(itemName: "Lassi", itemImage: "Lassi", itemPrice: "15")] )

let item4 = Restaurant(section:"Desserts",items_Array:[MenuItem(itemName:"gulabJamun",itemImage:"GulabJamun",itemPrice:"6"), MenuItem(itemName: "IceCream", itemImage: "IceCream", itemPrice: "4"), MenuItem(itemName: "Carrot Halwa", itemImage: "carrotHalwa", itemPrice: "14"), MenuItem(itemName: "Brownie", itemImage: "Brownie", itemPrice: "4")] )

let RestaurantList = [item1, item2, item3,item4]
