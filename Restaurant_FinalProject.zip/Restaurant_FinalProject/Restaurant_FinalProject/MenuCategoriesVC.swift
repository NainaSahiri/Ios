//
//  MenuCategoriesVC.swift
//  Restaurant_FinalProject
//
//  Created by Kalluri,Shanmukha Sriharsha on 12/6/22.
//

import UIKit

class MenuCategoriesVC: UIViewController, UITableViewDelegate, UITableViewDataSource  {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        categoryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = categoryTableview.dequeueReusableCell(withIdentifier:  "categoryCell", for: indexPath)
        cell.textLabel?.text = categoryList[indexPath.row].section
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "menusegu", sender: indexPath)
    }
    var categoryList = RestaurantList

    override func viewDidLoad() {
        super.viewDidLoad()
        categoryTableview.dataSource = self
        categoryTableview.delegate = self

        // Do any additional setup after loading the view.
    }
    
  
    
    @IBOutlet weak var categoryTableview: UITableView!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "menusegu"{
            let destination = segue.destination as! ItemsVC
            destination.itemsList = categoryList[(categoryTableview.indexPathForSelectedRow?.row)!].items_Array
            destination.title = categoryList[(categoryTableview.indexPathForSelectedRow?.row)!].section
            
        }
    }
}
