//
//  ItemsVC.swift
//  Restaurant_FinalProject
//
//  Created by Kalluri,Shanmukha Sriharsha on 12/6/22.
//

import UIKit

class ItemsVC: UIViewController, UITableViewDelegate, UITableViewDataSource  {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        itemsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = ItemTableview.dequeueReusableCell(withIdentifier:  "itemCell", for: indexPath)
        cell.textLabel?.text = itemsList[indexPath.row].itemName
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "detailSegu", sender: indexPath)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        ItemTableview.dataSource = self
        ItemTableview.delegate = self
        // Do any additional setup after loading the view.
    }
    
    var itemsList = [MenuItem]()
    

    @IBOutlet weak var ItemTableview: UITableView!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "detailSegu"{
            let destination = segue.destination as! DetailsVC
            destination.title = itemsList[(ItemTableview.indexPathForSelectedRow?.row)!].itemName
            destination.itemName = itemsList[(ItemTableview.indexPathForSelectedRow?.row)!].itemName
            destination.itemimg = itemsList[(ItemTableview.indexPathForSelectedRow?.row)!].itemImage
            destination.price = itemsList[(ItemTableview.indexPathForSelectedRow?.row)!].itemPrice
            
        }
    }
}
