//
//  DetailsVC.swift
//  Restaurant_FinalProject
//
//  Created by Kalluri,Shanmukha Sriharsha on 12/6/22.
//

import UIKit

class DetailsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        itemimgOutlet.image = UIImage(named: itemimg)
        ItempriceOutlet.text = "Item price is $"+price
        print(itemimg)
        
        

        // Do any additional setup after loading the view.
    }
    
    var itemName = ""
    var itemimg = ""
    var total = 0.0
    var price = ""
    
    @IBOutlet weak var itemimgOutlet: UIImageView!
    
    @IBOutlet weak var ItempriceOutlet: UILabel!
    
    @IBOutlet weak var quantityLBL: UITextField!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "conformSegu"{
            total = Double(price)! * Double(quantityLBL.text!)!
            let destination = segue.destination as! conformVC
            destination.message = "Your order is taken and Total price is $"+String(total)
            
            
        }
    }

}
