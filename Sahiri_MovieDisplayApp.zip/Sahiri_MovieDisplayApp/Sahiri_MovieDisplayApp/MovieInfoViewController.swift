//
//  MovieInfoViewController.swift
//  Sahiri_MovieDisplayApp
//
//  Created by Sahiri,Naina on 11/29/22.
//

import UIKit

class MovieInfoViewController: UIViewController {
    
    @IBOutlet weak var imgOutlet: UIImageView!
    
    
    @IBOutlet weak var mveNameOutlet: UILabel!
    
    
    @IBOutlet weak var mveCastOutlet: UILabel!
    
    
    @IBOutlet weak var mveRealesedOutlet: UILabel!
    
    
    
    @IBOutlet weak var mveCollectionOutlet: UILabel!
    
    var mve : Movie?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imgOutlet.image = UIImage(named: mve!.movieImage)
        mveNameOutlet.text = "Movie Name : \(mve!.movieName)"
        mveCastOutlet.text = "Movie Cast : \(mve!.movieCast)"
        mveRealesedOutlet.text = "Movie Released Year : \(mve!.movieReleasedYear)"
        mveCollectionOutlet.text = "Movie Collection : \(mve!.boxOfficeCollection)"
        
    }
    
}
