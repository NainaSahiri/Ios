//
//  ViewController.swift
//  Sahiri_MovieDisplayApp
//
//  Created by Sahiri,Naina on 11/29/22.
//

import UIKit

class MovieSectionViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mves.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableOutlet.dequeueReusableCell(withIdentifier: "movieSectionCell", for: indexPath)
        
        cell.textLabel?.text = mves[indexPath.row].movieName
        
        return cell
    }
    
    
    var mves = MovieArray
    
    
    @IBOutlet weak var tableOutlet: UITableView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableOutlet.delegate = self
        tableOutlet.dataSource = self
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        if transition == "movieInfoSegue"{
            
            let destination = segue.destination as! MovieInfoViewController
            
            
            destination.mve = mves[(tableOutlet.indexPathForSelectedRow?.row)!]
            
        }
    }

}
